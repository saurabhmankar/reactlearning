import { combineReducers } from 'redux';
import { reducer as formReducer } from 'redux-form'; // SAYING use redux form reducers as reducers
import loginReducer from './../modules/logins/reducers/LoginReducer';

const allReducers = combineReducers({
  form: formReducer,
  login: loginReducer,
});

export default allReducers;

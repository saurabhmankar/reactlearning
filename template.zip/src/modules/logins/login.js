
import React, { Component } from 'react';
import { loginAction } from './actions/LoginActions';
import { connect } from 'react-redux';
import { NavLink } from 'react-router-dom';
import './../../static/css/style.css';
class Login extends Component {

  constructor(props) {
    super(props);
  }

  componentWillMount() {
    this.props.loginAction();
  }

  render() {
    return (
      <div className="alt-txt">
        <h1>{this.props.pageName}</h1>
        <NavLink exact to="/dashboard/child1">Next</NavLink>
      </div>
    );
  }
}

function mapStateToProps(state) {
  return {
    pageName: state.login.pageName,
  };
}

export default connect(mapStateToProps, { loginAction })(Login);

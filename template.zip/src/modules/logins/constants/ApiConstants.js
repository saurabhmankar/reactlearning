/*
     Login Api Constants
*/
import {
    actionCreator,
    createRequestActionTypes,
} from './../../../actions/utilAction';
export {
    actionCreator,
};

export const loginActionTypes = {
    post_login: createRequestActionTypes('POST_LOGIN'),
};

/*
     Login Actions 
*/
import {
    actionCreator,
    loginActionTypes,
} from './../constants/ApiConstants';

export function loginAction() {
    return (dispatch) => {
        dispatch(actionCreator(loginActionTypes.post_login.SUCCESS, { errorMessage: null, pageName: "FirstPage" }));
    };
}








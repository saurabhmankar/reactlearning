/*
     Login Reducers 
*/
import { loginActionTypes } from './../constants/ApiConstants';

const initialState = {
    pageName: null,
    errorMessage: null,
};

export default (state = initialState, { type, payload }) => {
    switch (type) {
        case loginActionTypes.post_login.SUCCESS:
            return {
                ...state,
                authenticating: false,
                errorMessage: payload.errorMessage,
                pageName: payload.pageName,
            };

        default:
            return state;
    }
};


import React from 'react';

const Child2 = () => (
    <div>child2</div>
);

export default Child2;
import React from 'react';
import Drawer from 'material-ui/Drawer';
import MenuItem from 'material-ui/MenuItem';
import RaisedButton from 'material-ui/RaisedButton';
import { Redirect, Route, BrowserRouter as Router, Switch } from 'react-router-dom';
import PublicRoute from '../../../routers/PublicRoute';
import { Link } from 'react-router-dom';
import Child1 from './child1';
import Child2 from './child2';

export default class Dashboard extends React.Component {

  constructor(props) {
    super(props);
    this.state = { open: true };
  }

  handleToggle = () => this.setState({ open: !this.state.open });

  render() {
    return (
      <div style={{ marginLeft: '300px' }}>
        <Drawer open={this.state.open}>
          <MenuItem><Link to="/dashboard/child1">Menu Item</Link></MenuItem>
          <MenuItem><Link to="/dashboard/child2">Menu Item 2</Link></MenuItem>
        </Drawer>
        <RaisedButton
          label="Toggle Drawer"
          onClick={this.handleToggle}
        />
        <div style={{ marginLeft: '300px' }}>
          <Switch>
            <PublicRoute path="/dashboard/child1" component={Child1} />
            <PublicRoute path="/dashboard/child2" component={Child2} />
          </Switch>
        </div>
      </div>
    );
  }
}
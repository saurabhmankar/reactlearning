// import Login from './../login';
// import React from 'react';
// import Register from './../register';
// import { Route } from 'react-router-dom';

// // Sync route definition
// export default (
//     <div>
//       <Route exact path="/" component={Login} />
//       <Route exact path="/register" component={Register} />
//     </div>
// );

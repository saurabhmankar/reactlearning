import React, { Component } from 'react';
import { Redirect, Route, BrowserRouter as Router, Switch } from 'react-router-dom';
import LoginComponent from '../modules/logins/login';
import Dashboard from '../modules/PatientPortal/logins/login';
import PrivateRoute from './PrivateRoute';
import PublicRoute from './PublicRoute';

class RoutesComponent extends Component {
  render() {
    return (
      <div>
        <Switch>
          <PublicRoute path="/login" component={LoginComponent} />
          <PublicRoute path="/dashboard" component={Dashboard} />
          <PublicRoute path="*" component={LoginComponent} />
        </Switch>
      </div>
    );
  }
}

export default RoutesComponent;

/*
 * filename: routers.js
 * mainly responsivle for all routes component
 * change and sidebar routlist menu item
 * */

import React, { Component } from 'react';
import history from '../history';
import Main from './main';
import { Route } from 'react-router-dom';
import { Router } from 'react-router';

class Routers extends Component {
  render() {
    return (
      <Router history={history}>
        <Route component={Main} />
      </Router>
    );
  }
}

export default Routers;

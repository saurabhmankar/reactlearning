/*
 * filename: routers.js
 * mainly responsivle for all routes component
 * change and sidebar routlist menu item
 * */

import React, { Component } from 'react';
import RoutesComponent from './routesComponent.js';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';

class Main extends Component {
  render() {
    return (
      <div>
        <MuiThemeProvider>
          <RoutesComponent />
        </MuiThemeProvider>
      </div>
    );
  }
}

export default Main;

import React, { Component } from 'react';
import Routers from './routers/routers.js';

class App extends Component {
  render() {
    return (
      <Routers />
    );
  }
}

export default App;

/*
     Actions 
*/

let mydata = [
    {
        name: 'User 1',
        country: 'India'
    }, {
        name: 'User 2',
        country: 'US'
    }
]

function actionCreator(actionType, data) {
    return {
        type: actionType,
        payload: data
    };
}

function createRequestActionTypes(base) {
    return ["REQUEST", "SUCCESS", "FAILURE"].reduce((requestTypes, type) => {
        requestTypes[type] = `${base}_${type}`;
        return requestTypes;
    }, {});
}

export function getData() {

    // dispatch() is the method used to dispatch actions and trigger state changes to the store.

    return (dispatch) => {
        dispatch(actionCreator(createRequestActionTypes("GET_DATA").SUCCESS, { list: mydata }));
    };
}













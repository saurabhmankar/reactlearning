/*
     Reducers 
*/

const initialState = {
    list: []
};

// Reducers specify how the application's state changes in response to actions sent to the store.
export default (state = initialState, { type, payload }) => {

    switch (type) {

        case 'GET_DATA_SUCCESS':
            return {
                ...state,
                list: payload.list
            };

        default:
            return state;
    }
};

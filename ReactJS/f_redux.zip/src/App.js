import React from 'react';
import logo from './logo.svg';
import './App.css';
import { connect } from 'react-redux';
import { getData } from './action';

class App extends React.Component {

  componentDidMount() {
    // Action
    this.props.getData();
  }

  componentWillReceiveProps(nextProps) {
    console.log("list : ", nextProps.list)
  }

  render() {

    const listItems = this.props.list.map((n, index) =>
      <div key={index}>
        {n.name} - {n.country}
      </div>
    );

    return <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <div>{listItems}</div>
      </header>
    </div>
  }
}

// Used for selecting the part of the data from the store.
function mapStateToProps(state) {
  return {
    list: state.app.list
  };
}

// Connects a React component to a Redux store.
export default connect(mapStateToProps, {
  getData
})(App);


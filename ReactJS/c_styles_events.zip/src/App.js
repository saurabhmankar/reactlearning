import React from 'react';
import logo from './logo.svg';
import './App.css';
import { Button } from 'react-bootstrap';

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = { isToggleOn: true };

    // This binding is necessary to make `this` work in the callback
    this.buttonClick = this.buttonClick.bind(this);
  }

  buttonClick() {
    // fuction called on button click.
    alert('Button clicked')
  }

  render() {
    return (<div>
      <div className="head_row">Welcome</div>
      <div style={{ margin: '10px' }}>
        <button className="btn btn-success" type="button" onClick={this.buttonClick}>
          Click Here
          </button>
      </div>
    </div>)
  }
}

export default App;

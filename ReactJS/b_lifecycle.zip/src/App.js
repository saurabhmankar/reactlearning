import React from 'react';
import logo from './logo.svg';
import './App.css';

// React creates an instance of App

class App extends React.Component {

  // Initializing local state by assigning an object to this.state.
  // Binding event handler methods to an instance.
  constructor(props) {
    super(props);
    this.state = {
      list: []
    };
  }

  componentWillMount() {
    // invoked once.
    // avoid this.
    // fires before initial 'render' before DOM load.
    console.log('componentWillMount called');
  }

  componentDidMount() {
    // good for AJAX: fetch, ajax, or subscriptions.

    // invoked once.
    // fires before initial 'render' after DOM load.
    console.log('componentDidMount called');
  }

  componentWillReceiveProps(nextProps) {
    // invoked every time component recieves new props.
    // does not before initial 'render'
    console.log('componentWillReceiveProps called');
  }

  componentWillUnmount() {
    // invoked immediately before a component is unmounted.
    console.log('componentWillUnmount called');
  }

  shouldComponentUpdate(nextProps, nextState) {
    // invoked before every update (new props or state).
    // does not fire before initial 'render'.
  }

  componentDidUpdate(prevProps, prevState) {
    // invoked immediately after DOM updates
    // does not fire after initial 'render'
    console.log('componentDidUpdate called');
  }

  // The render() method is the only required method in a class component.
  // Rendering is the process of transforming your react components into DOM (Document Object Model) nodes that your browser can understand and display on the screen.
  render() {

    console.log('render called');
    
    return <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Hello <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  }
}
export default App;

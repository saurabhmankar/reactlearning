import React from 'react';
import logo from './logo.svg';
import './App.css';
import Child from './child';

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = { showText: false };
    this.buttonClick = this.buttonClick.bind(this);
  }

  buttonClick() {
    // Update state
    this.setState({
      showText: !this.state.showText
    })
  }

  render() {
    return (<div>
      <div style={{ margin: '10px' }}>
        <button className="btn btn-success" type="button" onClick={this.buttonClick}>
          Toggle
          </button>
        {/* Conditional rendering component */}
        {/* Passing props in child component */}
        {this.state.showText ? <Child name="App" /> : null}
      </div>
    </div>)
  }
}

export default App;

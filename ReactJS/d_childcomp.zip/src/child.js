import React from 'react';
import logo from './logo.svg';
import './App.css';

class Child extends React.Component {

    render() {
        return (<div style={{ background: 'blue', padding: '10px', color: 'white' }}>
            Child Page
            {/*To access props this.props.name */}
            <div>{this.props.name}</div>
        </div>)
    }
}

export default Child;
